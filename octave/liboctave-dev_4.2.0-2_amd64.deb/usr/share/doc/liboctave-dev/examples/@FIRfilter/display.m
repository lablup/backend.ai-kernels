function display (f)
  printf ("%s.polynomial", inputname (1));
  display (f.polynomial);
endfunction
