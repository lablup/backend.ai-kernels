function a = double (p)
  a = p.poly;
endfunction
