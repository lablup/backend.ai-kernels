function p = mtimes (a, b)
  p = polynomial (conv (double (a), double (b)));
endfunction
