function n = numel (obj, idx)
  n = 1;  # always produce an array.
endfunction
