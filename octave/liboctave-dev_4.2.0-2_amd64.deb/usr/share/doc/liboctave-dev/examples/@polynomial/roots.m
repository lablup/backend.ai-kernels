function r = roots (p)
  r = roots (fliplr (p.poly));
endfunction
