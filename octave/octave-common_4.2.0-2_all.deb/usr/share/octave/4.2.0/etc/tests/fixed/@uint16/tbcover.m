% !!! DO NOT EDIT !!!
% generated automatically by build-bc-overload-tests.sh
function s = tbcover (x, y)
  s = 'uint16';
