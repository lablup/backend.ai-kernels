# fB.m
function y = fB (x)
  y = x;
endfunction
