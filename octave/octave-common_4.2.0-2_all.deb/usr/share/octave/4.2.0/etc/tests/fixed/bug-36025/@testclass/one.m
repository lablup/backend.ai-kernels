% function ONE return item "X"

function a = one (m)
  a = m.x;
endfunction
