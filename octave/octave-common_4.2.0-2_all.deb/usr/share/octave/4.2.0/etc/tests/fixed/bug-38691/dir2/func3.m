function [r, f3] = func3 (x)
  f3 = "dir2/func3";
  r = 1;
endfunction
