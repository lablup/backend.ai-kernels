classdef class_bug44940 < handle
  properties
    child
  endproperties
endclassdef
