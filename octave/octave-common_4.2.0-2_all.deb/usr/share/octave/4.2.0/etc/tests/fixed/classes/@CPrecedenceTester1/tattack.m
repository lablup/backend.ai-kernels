function s = tattack (x, y)

  s = 'CPrecedenceTester1';

end
