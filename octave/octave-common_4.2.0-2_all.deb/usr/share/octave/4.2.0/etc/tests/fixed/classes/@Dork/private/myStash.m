function out = myStash ()

  out = 2;

end
