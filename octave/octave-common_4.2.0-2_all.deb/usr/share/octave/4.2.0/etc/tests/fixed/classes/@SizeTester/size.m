function s = size (this)

  s = this.desired_size;

endfunction
