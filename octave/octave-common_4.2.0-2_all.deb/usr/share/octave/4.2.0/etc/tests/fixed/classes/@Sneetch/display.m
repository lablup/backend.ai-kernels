function display ( s )

  disp ([inputname(1),'.mcbean = ']);
  disp (' ');
  disp (s.mcbean);
  disp ([inputname(1),'.sylvester = ']);
  disp (' ');
  disp (s.sylvester);

end
