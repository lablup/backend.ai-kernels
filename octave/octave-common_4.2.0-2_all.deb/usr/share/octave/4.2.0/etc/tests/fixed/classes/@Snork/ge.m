function b = ge (s1, s2)

  x1 = double (s1);
  x2 = double (s2);

  b = (x1(1) >= x2(1));

end
