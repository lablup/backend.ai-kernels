function out = getStash (l)

  out = myStash ();

end
