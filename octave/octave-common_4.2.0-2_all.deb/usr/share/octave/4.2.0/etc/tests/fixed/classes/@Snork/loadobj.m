function out = loadobj (in)

  out = in;
  out.cack = [-1 -2 -3 -4];

end
