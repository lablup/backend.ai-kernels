function b = ne (s1, s2)

  b = !(s1 == s2);

end
