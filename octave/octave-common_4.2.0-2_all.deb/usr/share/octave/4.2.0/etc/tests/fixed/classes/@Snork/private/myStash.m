function out = myStash ()

  out = 1;

end
