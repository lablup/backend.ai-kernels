function out = subsindex (obj)

  out = 0;

end
