function s = times (s1, s2, s3)

  x1 = double (s1);
  x2 = double (s2);

  s = Snork (x1 .* x2);

end
