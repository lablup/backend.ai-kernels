function out = getStash (cls)

  out = myStash ();

end
