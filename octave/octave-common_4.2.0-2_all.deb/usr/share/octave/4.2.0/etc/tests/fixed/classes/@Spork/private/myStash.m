function out = myStash ()

  out = 3;

end
