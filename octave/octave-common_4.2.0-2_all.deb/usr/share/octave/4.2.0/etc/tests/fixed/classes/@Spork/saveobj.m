function out = saveobj (in)

  out = in;
  %rmfield (out,'cack');

end
