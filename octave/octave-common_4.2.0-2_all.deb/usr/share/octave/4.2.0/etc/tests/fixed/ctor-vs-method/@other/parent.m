function r = parent (a)
  __trace__ ('begin other/parent');
  __trace__ ('end other/parent');
end
