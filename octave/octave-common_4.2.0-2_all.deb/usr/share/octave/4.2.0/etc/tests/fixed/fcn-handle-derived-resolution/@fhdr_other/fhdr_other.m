function r = fhdr_other (n)
  s.d = fhdr_derived (n);
  r = class (s, 'fhdr_other');
end
