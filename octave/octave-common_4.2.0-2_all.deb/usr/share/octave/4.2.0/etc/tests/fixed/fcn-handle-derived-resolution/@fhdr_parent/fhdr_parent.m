function r = fhdr_parent (n)
  s.a = rand (n, 1);
  r = class (s, 'fhdr_parent');
end
