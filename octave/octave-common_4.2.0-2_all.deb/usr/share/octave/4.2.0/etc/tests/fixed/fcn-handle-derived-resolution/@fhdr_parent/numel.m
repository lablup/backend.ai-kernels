function r = numel (x, varargin)
  r = numel (x.a, varargin{:});
end
