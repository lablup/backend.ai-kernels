# scope0.m
function scope0
  C;
  function A
    B;
    function B
    endfunction
  endfunction

  function C
    D;
    function D
      A;
    endfunction
  endfunction
endfunction
