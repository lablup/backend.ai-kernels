

class Turtle:

    def __init__(self, canvas):
        self.canvas = canvas
        # TODO: create cursor

    def forward(self, length):
        pass

    def left(self, deg):
        pass

    def right(self, deg):
        pass


__all__ = [
    'Turtle',
]
