import unittest


class NullTest(unittest.TestCase):

    def test_none(self):
        pass
